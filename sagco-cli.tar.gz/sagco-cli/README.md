# SAGCO-CLI v0.1.0
Field Engineering Productivity CLI — Strategickhaos DAO LLC

## Build (requires Rust 1.80+)
```bash
cargo build --release
```

## Commands
```bash
./sagco-cli compute  --config sagco.master.yaml
./sagco-cli audit    --config sagco.master.yaml
./sagco-cli validate --config sagco.master.yaml
```

## Expected output (compute)
```
Est Hours  : 4979.0
Act Hours  : 3583.3
Remaining  : 1395.7
CPI        : 1.390
Variance   : -28.0%
Savings    : $107,468.90
STATUS     : AHEAD
```

## Real data
PO 4406147216 | Blend Rate $77/hr | 12 circuits
