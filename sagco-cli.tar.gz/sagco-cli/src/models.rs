use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Circuit {
    pub cui_number: String,
    pub circuit_id: String,
    pub est_hours:  f64,
    pub act_hours:  f64,
    pub lnft:       f64,
    pub sqft:       f64,
    pub status:     String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SagcoConfig {
    pub project:               String,
    pub po:                    String,
    pub blend_rate:            f64,
    pub difficulty_multiplier: f64,
    pub circuits:              Vec<Circuit>,
}

#[derive(Debug)]
pub struct Metrics {
    pub total_est:       f64,
    pub total_act:       f64,
    pub cpi:             f64,
    pub variance_pct:    f64,
    pub remaining_hours: f64,
    pub savings_dollars: f64,
}
