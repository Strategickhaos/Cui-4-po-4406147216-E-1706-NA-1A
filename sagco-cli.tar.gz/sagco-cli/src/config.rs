use anyhow::Result;
use crate::models::SagcoConfig;

pub fn load(path: &str) -> Result<SagcoConfig> {
    let text = std::fs::read_to_string(path)?;
    let cfg: SagcoConfig = serde_yaml::from_str(&text)?;
    Ok(cfg)
}
