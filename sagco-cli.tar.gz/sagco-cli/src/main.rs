use clap::Parser;
use anyhow::Result;

mod config;
mod models;
mod engines;
mod commands;

#[derive(Parser)]
#[command(author, version, about = "SAGCO Field Engineering CLI")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(clap::Subcommand)]
enum Commands {
    Compute(commands::compute::ComputeArgs),
    Audit(commands::audit::AuditArgs),
    Validate(commands::validate::ValidateArgs),
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::Compute(args)  => commands::compute::execute(args),
        Commands::Audit(args)    => commands::audit::execute(args),
        Commands::Validate(args) => commands::validate::execute(args),
    }
}
