use crate::models::{SagcoConfig, Metrics};

pub fn compute(cfg: &SagcoConfig) -> Metrics {
    let total_est: f64 = cfg.circuits.iter().map(|c| c.est_hours).sum();
    let total_act: f64 = cfg.circuits.iter().map(|c| c.act_hours).sum();
    let remaining  = total_est - total_act;
    let cpi        = if total_act > 0.0 { total_est / total_act } else { 0.0 };
    let var_pct    = if total_est > 0.0 {
        (total_act - total_est) / total_est * 100.0
    } else { 0.0 };
    let savings = remaining * cfg.blend_rate;
    Metrics {
        total_est,
        total_act,
        cpi,
        variance_pct: var_pct,
        remaining_hours: remaining,
        savings_dollars: savings,
    }
}

pub fn circuit_verdict(est: f64, act: f64) -> &'static str {
    if est == 0.0         { return "INACTIVE"; }
    let r = est - act;
    if r < -100.0         { "CRITICAL OVER" }
    else if r < 0.0       { "OVER" }
    else if r < est * 0.1 { "NEAR LIMIT" }
    else if r > est * 0.5 { "BANKED" }
    else                  { "UNDER" }
}
