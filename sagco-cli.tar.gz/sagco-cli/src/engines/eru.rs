use crate::models::Circuit;

pub struct EruResult {
    pub circuit_id:    String,
    pub estimated:     f64,
    pub used:          f64,
    pub remaining:     f64,
    pub dollar_at_risk: f64,
    pub is_overrun:    bool,
}

pub fn analyze(circuits: &[Circuit], blend_rate: f64) -> Vec<EruResult> {
    circuits.iter().map(|c| {
        let remaining = c.est_hours - c.act_hours;
        let is_overrun = remaining < 0.0;
        let dollar_at_risk = if is_overrun {
            remaining.abs() * blend_rate
        } else {
            0.0
        };
        EruResult {
            circuit_id: c.circuit_id.clone(),
            estimated: c.est_hours,
            used: c.act_hours,
            remaining,
            dollar_at_risk,
            is_overrun,
        }
    }).collect()
}

pub fn total_overrun(results: &[EruResult]) -> f64 {
    results.iter()
        .filter(|r| r.is_overrun)
        .map(|r| r.remaining.abs())
        .sum()
}

pub fn total_banked(results: &[EruResult]) -> f64 {
    results.iter()
        .filter(|r| !r.is_overrun)
        .map(|r| r.remaining)
        .sum()
}
