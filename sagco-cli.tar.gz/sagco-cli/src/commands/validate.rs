use clap::Parser;
use anyhow::Result;
use crate::config;

#[derive(Parser)]
pub struct ValidateArgs {
    #[arg(short, long, default_value = "sagco.master.yaml")]
    pub config: String,
}

pub fn execute(args: ValidateArgs) -> Result<()> {
    let cfg = config::load(&args.config)?;
    println!("Config valid: {} circuits, PO {}, blend rate ${}/hr",
        cfg.circuits.len(), cfg.po, cfg.blend_rate);
    for c in &cfg.circuits {
        if c.est_hours < 0.0 {
            anyhow::bail!("Circuit {} has negative est_hours", c.circuit_id);
        }
        if c.act_hours < 0.0 {
            anyhow::bail!("Circuit {} has negative act_hours", c.circuit_id);
        }
    }
    println!("All {} circuits pass validation.", cfg.circuits.len());
    Ok(())
}
