use clap::Parser;
use anyhow::Result;
use crate::{config, engines::productivity};

#[derive(Parser)]
pub struct ComputeArgs {
    #[arg(short, long, default_value = "sagco.master.yaml")]
    pub config: String,
}

pub fn execute(args: ComputeArgs) -> Result<()> {
    let cfg = config::load(&args.config)?;
    let m   = productivity::compute(&cfg);

    println!("═══════════════════════════════════════════");
    println!("  SAGCO COMPUTE  |  {}  |  PO {}", cfg.project, cfg.po);
    println!("═══════════════════════════════════════════");
    println!("  Est Hours   : {:>10.1}", m.total_est);
    println!("  Act Hours   : {:>10.1}", m.total_act);
    println!("  Remaining   : {:>10.1}", m.remaining_hours);
    println!("  CPI         : {:>10.3}", m.cpi);
    println!("  Variance    : {:>9.1}%", m.variance_pct);
    println!("  Savings @${}.: {:>10}", cfg.blend_rate,
             format!("${:.2}", m.savings_dollars));
    println!("  STATUS      : {}", if m.cpi >= 1.0 { "AHEAD" } else { "BEHIND" });
    println!("═══════════════════════════════════════════");
    Ok(())
}
