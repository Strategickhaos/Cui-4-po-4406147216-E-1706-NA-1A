use clap::Parser;
use anyhow::Result;
use crate::{config, engines::{productivity::circuit_verdict, eru}};

#[derive(Parser)]
pub struct AuditArgs {
    #[arg(short, long, default_value = "sagco.master.yaml")]
    pub config: String,
}

pub fn execute(args: AuditArgs) -> Result<()> {
    let cfg = config::load(&args.config)?;
    let eru_results = eru::analyze(&cfg.circuits, cfg.blend_rate);

    println!("{:<4} {:<20} {:>8} {:>8} {:>8} {:>7}  {:>12}  {}",
        "CUI","CIRCUIT","EST","ACT","REMAIN","VAR%","$AT RISK","VERDICT");
    println!("{}", "─".repeat(82));

    for (c, e) in cfg.circuits.iter().zip(eru_results.iter()) {
        let vpct = if c.est_hours > 0.0 {
            (c.est_hours - c.act_hours) / c.est_hours * 100.0
        } else { 0.0 };
        let risk_str = if e.is_overrun {
            format!("${:.0}", e.dollar_at_risk)
        } else {
            format!("BANKED ${:.0}", e.remaining)
        };
        println!("{:<4} {:<20} {:>8.1} {:>8.1} {:>8.1} {:>6.1}%  {:>12}  {}",
            c.cui_number, c.circuit_id,
            c.est_hours, c.act_hours, e.remaining, vpct,
            risk_str,
            circuit_verdict(c.est_hours, c.act_hours));
    }

    println!("{}", "─".repeat(82));
    let te: f64 = cfg.circuits.iter().map(|c| c.est_hours).sum();
    let ta: f64 = cfg.circuits.iter().map(|c| c.act_hours).sum();
    let overrun  = eru::total_overrun(&eru_results);
    let banked   = eru::total_banked(&eru_results);

    println!("{:<4} {:<20} {:>8.1} {:>8.1} {:>8.1}",
        "ALL", "TOTAL", te, ta, te - ta);
    println!();
    println!("  Overrun hours : {:.1} (${:.2})", overrun, overrun * cfg.blend_rate);
    println!("  Banked hours  : {:.1} (${:.2})", banked,  banked  * cfg.blend_rate);
    println!("  Net position  : ${:.2}", (banked - overrun) * cfg.blend_rate);
    Ok(())
}
